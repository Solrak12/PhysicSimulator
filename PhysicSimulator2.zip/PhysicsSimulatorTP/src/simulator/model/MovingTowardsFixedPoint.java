package simulator.model;

import java.util.List;

import simulator.misc.Vector2D;

public class MovingTowardsFixedPoint implements ForceLaws{

	private Vector2D c;
	private double g;
	
	
	public MovingTowardsFixedPoint(Vector2D c,double g) {
		if((g<0) ||  (c==null) ){
			
			throw new IllegalArgumentException("Non valid arguments for MovingTowardsFixedPoint");
		}
		this.c = c;
		this.g=g;
		
	}
	@Override
	public void apply(List<Body> bs) {
		for(Body b :bs) {
			Vector2D dir = b.getPosition().direction(); //direccion		
			Vector2D m = dir.scale(b.getMass()); //masa * direccion
			Vector2D f = m.scale(g); //F = d * m * g  //luis esto es g o menos g
			b.addForce(f);
		}
	
	}
	

}
