package simulator.model;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class PhysicsSimulator {
	private double tiempo;
	private ForceLaws fuerza;
	private List<Body> cuerpos;
	private List<BodiesGroup> grupos;

public PhysicsSimulator(double tiempo, ForceLaws fuerza) {
	if((tiempo<0) ||  (fuerza==null) ){
		
		throw new IllegalArgumentException("Non valid arguments for PhysicSimulator");
	}
	this.tiempo = tiempo;
	this.fuerza = fuerza;
}
public void advance() {
	for(Body b : cuerpos) {
		b.resetForce();
	}
	fuerza.apply(cuerpos);
	//Completar
}
public void addGroup(String id) {
	for(BodiesGroup bo: grupos) {
		if(bo.getGid().equals(id)) {
			throw new IllegalArgumentException("Ya exite un grupo con esa id");
		}
		else {
			grupos.add(bo);
			bo.resetForce();
		}
	}
	
}
void addBody(Body b) {
	for(Body bo: cuerpos) {
		if(bo.getGid().equals(b.getGid())) {
			throw new IllegalArgumentException("Ya exite un grupo con esa id");
		}
	}
	cuerpos.add(b);
	
}
public void setForceLaws(String id, ForceLaws fl) {
	for(Body b :cuerpos) {
		
	if(id != b.getGid()) {
		this.fuerza = fl;
	}
	else throw new IllegalArgumentException("Ya exite un grupo con esa id");
	}
		
}
public JSONObject getState() {
	List<String> ids = null;
	JSONObject jo1 = new JSONObject();
	jo1.put("time", tiempo);
	JSONArray ja = new JSONArray();
	for(Body b:cuerpos) { //Recorre la lista de cuerpos y los añade a jo1
		ids.add(b.getGid());
		ids.sort(null);		//Carlos No se muy bien como hacer lo de la lista de strings
		ja.put(b.getState());
	}
	jo1.put("groups", ja);
	
	return jo1;
	
}
public String toString() {
	return getState().toString();
}






}