package simulator.model;

public class NewtonUniversalGravitation {
	private static final double g =-(6.67 *(Math.pow(10, -11))); //Valor gravitacional negativo
}
