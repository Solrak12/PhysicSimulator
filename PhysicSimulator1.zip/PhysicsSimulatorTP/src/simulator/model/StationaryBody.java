package simulator.model;

import simulator.misc.Vector2D;

public class StationaryBody extends Body {

	public StationaryBody(String id, String gid, Vector2D p, Vector2D v, double masa) {
		super(id, gid, p, v, masa);
		// TODO Auto-generated constructor stub
	}
	public void advance(double dt) {
		//Vacio no hace nada
	}

}
