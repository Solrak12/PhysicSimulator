package simulator.model;

import java.util.List;

import simulator.misc.Vector2D;

public class MovingTowardsFixedPoint implements ForceLaws{

	private static final double g =-(6.67 *(Math.pow(10, -11))); //Valor gravitacional negativo
	private Vector2D c;
	
	
	
	public MovingTowardsFixedPoint(Vector2D c) {
		this.c = c;
		
	}
	@Override
	public void apply(List<Body> bs) {
		for(Body b :bs) {
			Vector2D dir = b.getP().direction(); //direccion		
			Vector2D m = dir.scale(b.getMasa()); //masa * direccion
			Vector2D f = m.scale(g); //F = d * m * g
			b.addForce(f);
		}
	
	}
	

}
