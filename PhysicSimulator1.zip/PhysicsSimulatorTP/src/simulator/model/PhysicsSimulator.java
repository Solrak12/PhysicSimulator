package simulator.model;

public class PhysicsSimulator {
	private double tiempo;
	private ForceLaws fuerza;
}
