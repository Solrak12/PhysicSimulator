package simulator.model;

import java.util.List;

import org.json.JSONObject;

import simulator.misc.Vector2D;

public class BodiesGroup extends Body{

	private String id;
	private ForceLaws fuerza;
	private List<Body> cuerpos;
	
	
	
	public BodiesGroup(String id, String gid, Vector2D p, Vector2D v, double masa,String idg,ForceLaws fuerza) {
		super(id, gid, p, v, masa);
		this.id = idg;
		this.fuerza = fuerza;
	}



	public String getId() {
		return id;
	}

	void addBody(Body b) {
		for(Body bo: cuerpos) {
			if(bo.equals(id)) {
				throw new IllegalArgumentException("Ya exite un cuerpo con esa id");
			}
		}
		cuerpos.add(b);
		
	}
	public void setFuerza(ForceLaws fuerza) {
		this.fuerza = fuerza;
	}
	public JSONObject getState() {
		JSONObject jo1 = new JSONObject();
		jo1.put("id", id);
		for(Body b:cuerpos) { //Recorre la lista de cuerpos y los añade a jo1
			jo1.put("bodies", b);
		}
		
		return jo1;
		
	}
	public String toString() {
		return getState().toString();
	}


}
