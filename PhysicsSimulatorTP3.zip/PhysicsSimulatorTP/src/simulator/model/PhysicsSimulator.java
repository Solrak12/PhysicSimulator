package simulator.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.factories.Builder;

public class PhysicsSimulator {
	private double tiempo;
	private ForceLaws fuerza;
	private List<Body> cuerpos;
	private List<String> grupos;
	private Map<String,BodiesGroup> mapa ;

public PhysicsSimulator(double tiempo, ForceLaws fuerza) {
	if((tiempo<0) ||  (fuerza==null) ){
		
		throw new IllegalArgumentException("Non valid arguments for PhysicSimulator");
	}
	this.tiempo = tiempo;
	this.fuerza = fuerza;
	mapa=new HashMap<String,BodiesGroup>();
	cuerpos=new ArrayList<Body>();
	grupos = new ArrayList<String>();
}
public void advance() {
	for(Body b : cuerpos) {
		b.resetForce();
		fuerza.apply(cuerpos);
		b.advance(tiempo);
	}
	
	
}
public void addGroup(String id) {
	
		if(mapa.containsKey(id)) {
			throw new IllegalArgumentException("Ya exite un grupo con esa id");
		}
		else {
		BodiesGroup bg=	new BodiesGroup(id,fuerza);
			mapa.put(id, bg);
			grupos.add(id);
			setForceLaws(id, fuerza);
		}
	}
	

public void addBody(Body b) {
	for(Body bo: cuerpos) {
		if(bo.getGid().equals(b.getGid())) {
			throw new IllegalArgumentException("Ya exite un grupo con esa id");
		}
	}
	cuerpos.add(b);
	
}
public void setForceLaws(String id, ForceLaws fl) {
	for(Body b :cuerpos) {
		
	if(id != b.getGid()) {
		this.fuerza = fl;
	}
	else throw new IllegalArgumentException("Ya exite un grupo con esa id");
	}
		
}
public JSONObject getState() {
	JSONObject jo1 = new JSONObject();
	BodiesGroup b;
	jo1.put("time", tiempo);
	JSONArray ja = new JSONArray();
	for(String bg: grupos) { //Recorre la lista de cuerpos y los añade a jo1
		b=mapa.get(bg);
		
		ja.put(b.getState());
	}
	jo1.put("groups", ja);
	
	return jo1;
	
}
public String toString() {
	return getState().toString();
}


}