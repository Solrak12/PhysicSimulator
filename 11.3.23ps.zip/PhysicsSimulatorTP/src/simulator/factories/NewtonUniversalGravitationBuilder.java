package simulator.factories;

import org.json.JSONException;
import org.json.JSONObject;


import simulator.model.ForceLaws;

import simulator.model.NewtonUniversalGravitation;

public class NewtonUniversalGravitationBuilder extends Builder<ForceLaws> {

	public NewtonUniversalGravitationBuilder(String typeTag, String desc) {
		super(typeTag, desc);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected ForceLaws createInstance(JSONObject data) {
		// TODO Auto-generated method stub
		
			
			     // luis campo por defecto
			
		
			try {
				
				if (getTypeTag().equals(data.getString("type"))) {
					

					if(data.has("G")) {             //luis ,variable optativa
						
						double g = data.getDouble("G");
						
						return new NewtonUniversalGravitation(g);
					}
					
					else {return new NewtonUniversalGravitation();}
					
					
				}
				
				}
				catch(JSONException joe) {
					throw new IllegalArgumentException("Non valid arguments for MovingTowardsFixedPoint");
					
				}

				return null;

	}

}
