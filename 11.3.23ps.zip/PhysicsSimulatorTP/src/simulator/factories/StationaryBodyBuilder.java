package simulator.factories;

import org.json.JSONException;
import org.json.JSONObject;

import simulator.misc.Vector2D;
import simulator.model.Body;
import simulator.model.StationaryBody;




public class StationaryBodyBuilder extends Builder<Body> {

	public StationaryBodyBuilder(String typeTag, String desc) {
		super(typeTag, desc);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected StationaryBody createInstance(JSONObject data) {
		// TODO Auto-generated method stub
		
		try {
			
			if(getTypeTag().equals(data.getString("type"))) {
				
				
				JSONObject _data= data.getJSONObject("data");
				String id=_data.getString("id");
						
						String gid=_data.getString("gid");
			Vector2D p = new Vector2D(_data.getJSONArray("p").getDouble(0), _data.getJSONArray("p").getDouble(1)); 
			Vector2D v = new Vector2D(_data.getJSONArray("v").getDouble(0), _data.getJSONArray("v").getDouble(1));
			double m=_data.getDouble("m");
			return new StationaryBody(id,gid,v,p,m);
		
		}
	} catch (JSONException joe) {
		throw new IllegalArgumentException("data of moving body failed");
	}

	return null;
}
}
