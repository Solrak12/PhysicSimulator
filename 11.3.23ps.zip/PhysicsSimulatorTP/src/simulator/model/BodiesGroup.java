package simulator.model;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Vector2D;

public class BodiesGroup {

	private String id;
	private ForceLaws fuerza;
	private List<Body> cuerpos;
	
	
	public BodiesGroup(String id,ForceLaws fuerza) {
	//super(id, gid, p, v, masa);
		this.id = id;
		this.fuerza = fuerza;
		
	}

	public String getId() {
		return id;
	}

	void addBody(Body b) {
		for(Body bo: cuerpos) {
			if(bo.getId().equals(id)) {
				throw new IllegalArgumentException("Ya exite un cuerpo con esa id");
			}
		}
		cuerpos.add(b);
		
	}
	void advance(double dt) {
		for(Body b : cuerpos) {
			if(dt>=0){
				b.resetForce();
				fuerza.apply(cuerpos);
				b.advance(dt);
			}
			else throw new IllegalArgumentException("El tiempo no puede ser negativo");
		}

	}
	public void setFuerza(ForceLaws fuerza) {
		this.fuerza = fuerza;
	}
	public JSONObject getState() {
		JSONObject jo1 = new JSONObject();
		jo1.put("id", id);
		JSONArray ja = new JSONArray();
		for(Body b:cuerpos) { //Recorre la lista de cuerpos y los añade a jo1
			ja.put(b);
		}
		jo1.put("Bodies", ja);
		
		return jo1;
		
	}
	public String toString() {
		return getState().toString();
	}


}
