package simulator.model;

import simulator.misc.Vector2D;

public class MovingBody extends Body {

	Vector2D a = new Vector2D(0,0);
	
	public MovingBody(String id, String gid, Vector2D p, Vector2D v, double masa) {
		super(id, gid, p, v, masa);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void advance(double dt) {
		if(masa != 0) {
		a = f.scale(1/masa); //a = f/m
	
		}
		else {
			a = new Vector2D(0,0);
		}
		v= v.plus(a.scale(dt)); //v +at =v
		p = p.plus(v.scale(dt)).plus(a.scale(Math.pow(dt, 2)/2)); //p = p+vt+1/2at^2
	}
	
	
}
