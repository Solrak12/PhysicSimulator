package simulator.model;

import java.util.*;

import simulator.misc.Vector2D;

public abstract class Body {
	protected String id;
	protected String gid;
	protected Vector2D v;
	protected Vector2D f;
	protected Vector2D p;
	protected double masa;


public Body(String id,String gid, Vector2D p, Vector2D v, double masa) {
	
	this.id = id;
	this.gid = gid;
	this.p = p;
	this.v =v;
	this.masa = masa;
	this.f = new Vector2D(0,0);
}


public String getId() {
	return id;
}


public void setId(String id) {
	this.id = id;
}


public Vector2D getV() {
	return v;
}




public Vector2D getF() {
	return f;
}




public Vector2D getP() {
	return p;
}





public double getMasa() {
	return masa;
}




}