package simulator.model;

import simulator.misc.Vector2D;

public class MovingBody extends Body {

	public MovingBody(String id, String gid, Vector2D p, Vector2D v, double masa) {
		super(id, gid, p, v, masa);
		// TODO Auto-generated constructor stub
	}

}
