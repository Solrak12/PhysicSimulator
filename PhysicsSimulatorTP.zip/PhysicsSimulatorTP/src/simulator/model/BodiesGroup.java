package simulator.model;

import java.util.List;

import simulator.misc.Vector2D;

public class BodiesGroup extends Body{

	private String id;
	private ForceLaws fuerza;
	private List<Body> cuerpos;
	
	
	
	public BodiesGroup(String id, String gid, Vector2D p, Vector2D v, double masa,String idg,ForceLaws fuerza) {
		super(id, gid, p, v, masa);
		this.id = idg;
		this.fuerza = fuerza;
	}



	public String getId() {
		return id;
	}


	public void setFuerza(ForceLaws fuerza) {
		this.fuerza = fuerza;
	}

}
