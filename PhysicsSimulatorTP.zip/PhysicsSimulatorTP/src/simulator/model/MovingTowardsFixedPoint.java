package simulator.model;

import java.util.List;

import simulator.misc.Vector2D;

public class MovingTowardsFixedPoint implements ForceLaws{

	private static final double g = 0; //Calcular valor
	private Vector2D c;
	private double masa;
	@Override
	public void apply(List<Body> bs) {
		// TODO Auto-generated method stub
	
	}
	public MovingTowardsFixedPoint(Vector2D c, double masa) {
		this.c = c;
		this.masa = masa; //Masa tambien?
	}

}
