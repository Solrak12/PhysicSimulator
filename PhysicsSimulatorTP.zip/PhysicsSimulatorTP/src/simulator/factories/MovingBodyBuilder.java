package simulator.factories;

package simulator.factories;

import org.json.JSONObject;

import simulator.misc.Vector2D;
import simulator.model.Body;

/*{
"type" : "mv_body",
"data" : {
  "id" : "b2",
  "gid" : "g1",
  "p" : [ 0.0, -4.5E10 ],
  "v" : [ -10000.0, 0.0 ],
  "m" : 1.5E30
}*/

public class MovingBodyBuilder extends Builder<Body> {

	public MovingBodyBuilder(String typeTag, String desc) {
		super(typeTag, desc);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Body createInstance(JSONObject data)throws IllegalArgumentException {
		// TODO Auto-generated method stub
		///Comprobar si existe un campo de un json : data.has("clave")
		//obtener un campo de  json : data.get+"tipo del dato a obtener"("clave").
		if(data.has("type")&&data.has("data")&&data.has("data")&&data.has("type")&&)
		
		
			
			 //Body(String id,String gid,Vector2D velocidad,Vector2D posicion,Double masa)
		return null;
	}

	
	}


