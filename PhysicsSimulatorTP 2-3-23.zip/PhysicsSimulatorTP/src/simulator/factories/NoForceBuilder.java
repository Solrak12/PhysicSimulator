package simulator.factories;

import org.json.JSONException;
import org.json.JSONObject;

import simulator.model.ForceLaws;
import simulator.model.NoForce;

public class NoForceBuilder extends Builder <ForceLaws> {

	public NoForceBuilder(String typeTag, String desc) {
		super(typeTag, desc);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected ForceLaws createInstance(JSONObject data) {
		// TODO Auto-generated method stub
		
		try{
			if (getTypeTag().equals(data.getString("type"))) {return new NoForce();}  //luis getTypeTag() es una funcion de Builder
		}
		catch(JSONException je){
			throw new IllegalArgumentException("The type must be a string ");
		}
		
		return null;
	}
		
	}

}
