package simulator.factories;

import org.json.JSONException;
import org.json.JSONObject;

import simulator.misc.Vector2D;
import simulator.model.ForceLaws;
import simulator.model.MovingTowardsFixedPoint;

public class MovingTowardsFixedPointBuilder  extends Builder<ForceLaws>{

	public MovingTowardsFixedPointBuilder(String typeTag, String desc) {
		super(typeTag, desc);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected ForceLaws createInstance(JSONObject data) {
		// TODO Auto-generated method stub
		
		double g=9.81;     // luis campo por defecto
		
	
		try {
			
			if (getTypeTag().equals(data.getString("type"))) {
				

				if(data.has("g")) {             //luis si g viene por defecto se guarda en la variable g sino se inicializa con 9.81 por defecto
					
					g=data.getDouble("g");
				}
				
				if(data.has("c")) {
				Vector2D v= new Vector2D(data.getJSONArray("c").getDouble(0),data.getJSONArray("c").getDouble(1));
				
				return new MovingTowardsFixedPoint(v,g);
				
				} 
					
				return new  MovingTowardsFixedPoint(new Vector2D(0,0),g);    //luis si no existe el valor opcional c , se utiliza el valor por defecto para el vector 2d (0.0)
					
					
				
				
				
			}
			
			}
			catch(JSONException joe) {
				throw new IllegalArgumentException("Non valid arguments for MovingTowardsFixedPoint");
				
			}

			return null;

}
}