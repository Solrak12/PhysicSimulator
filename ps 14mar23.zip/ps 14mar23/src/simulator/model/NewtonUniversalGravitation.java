package simulator.model;

import java.util.List;

import simulator.misc.Vector2D;

public class NewtonUniversalGravitation implements ForceLaws {
	// luis no entiendo esto en el pdf viene de otra forma //private static final double g =-(6.67 *(Math.pow(10, -11))); //Valor gravitacional negativo
//luis no puede ser final ademas ,porque puede no tener parametro en la factoria
	
	private static double G =6.67E-11;
	
	public NewtonUniversalGravitation(){};
	public NewtonUniversalGravitation(double G){
		this.G = G;
	}
	
	
	//luis Body.getP()=get posicion ,Body.getV()= get de la velocidad....
	@Override
	public void apply(List<Body> bs) {
		Vector2D Fuerzai;																	//luis Fuerza total sobre el cuerpo Bi
		for(Body Bodyi: bs) {
			Fuerzai= new Vector2D(0,0);
			for(Body Bodyj: bs) {
				if(Bodyi != Bodyj) {																//luis Si son iguales no se calcula
											
					Vector2D Fuerzaij;														//luis Fuerza entre el cuerpo Bi y el cuerpo Bj
					double distancia= Bodyj.getPosition().distanceTo(Bodyi.getPosition());	//luis |pj-pi|  // luis distanceTO funcion de la clase vector2d
					
					//luis Calculamos Fij
					double fuerzaij = G*(Bodyi.getMass()*Bodyj.getMass())/Math.pow(distancia,2);		//luis Modulo de la fuerza Fij
					Vector2D dij= (Bodyj.getPosition().minus(Bodyi.getPosition())).direction();	//luis Direccion de Fij
					Fuerzaij= new Vector2D(dij.scale(fuerzaij));
					
					//luis Sumamos la fuerza Fij a la total Fi
					Fuerzai= Fuerzai.plus(Fuerzaij);
				}	
			}
			Bodyi.addForce(Fuerzai);	//luis Aplicamos la fuerza
		}
		
	}
	
}
