package simulator.model;

import java.util.*;

import org.json.JSONObject;

import simulator.misc.Vector2D;

public abstract class Body {
	protected String id;
	protected String gid;
	protected Vector2D v;
	protected Vector2D f;
	protected Vector2D p;
	protected double masa;


public Body(String id,String gid, Vector2D p, Vector2D v, double masa) {
	
	this.id = id;
	this.gid = gid;
	this.p = p;
	this.v =v;
	this.masa = masa;
	this.f = new Vector2D(0,0);
}


public String getId() {
	return id;
}
public String getGid() {
	return gid;
}


public Vector2D getVelocity() {
	return v;
}


public Vector2D getForce() {
	return f;
}

public Vector2D getPosition() {
	return p;
}


public double getMass() {
	return masa;
}
void resetForce() {
	this.f = new Vector2D();
}
void addForce(Vector2D f) {
	this.f = this.f.plus(f);
}
void advance(double dt) {
	
}
public JSONObject getState() {
	JSONObject jo1 = new JSONObject();
	jo1.put("id", id);
	jo1.put("m", masa);
	jo1.put("p", p.asJSONArray());
	jo1.put("v", v.asJSONArray());
	jo1.put("f", f.asJSONArray());
	
	return jo1;
	
}

public String toString() {
	return getState().toString();
}


}