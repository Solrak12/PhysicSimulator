package simulator.control;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.factories.Factory;
import simulator.factories.MovingTowardsFixedPointBuilder;
import simulator.model.BodiesGroup;
import simulator.model.Body;
import simulator.model.ForceLaws;
import simulator.model.PhysicsSimulator;
import simulator.factories.BuilderBasedFactory;

public class Controller {
	PhysicsSimulator _simulador;
	Factory<Body> _fb;
	Factory<ForceLaws> _fl;
	public Controller(PhysicsSimulator p,Factory<Body> fb,Factory<ForceLaws> fl) {
		
		_simulador= p;
		_fb = fb;
		_fl =fl;
		
	}
	
	public void loadData(InputStream in){
	
		
		JSONObject jsonInput = new JSONObject(new JSONTokener(in));
		JSONArray groups = jsonInput.getJSONArray("groups");
		
		JSONArray laws = jsonInput.getJSONArray("laws");
		JSONArray bodies = jsonInput.getJSONArray("bodies");
		
		//grupos 
		
		if(!(jsonInput.has("groups"))) {throw new IllegalArgumentException("Physics simulator needs Bodies group");
		}
		if(!(jsonInput.has("bodies"))){throw new IllegalArgumentException("Physic simulator need bodies");
		}
		
		for(int i=0;i<groups.length();i++) {
			_simulador.addGroup( groups.getString(i));
			
		}
		
		//laws (opcional si no hay laws no entra al for)
		
		for(int i=0;i<laws.length();i++) {
			_simulador.setForceLaws(laws.getJSONObject(i).getString("id"), _fl.createInstance(laws.getJSONObject(i).getJSONObject("laws")));
			
			
		}
		for(int i=0;i<bodies.length();i++) {
			_simulador.addBody(_fb.createInstance(bodies.getJSONObject(i)));
			
		}
		//QJWHGFRIUYIEPUW	�riepoayutiuoye LUIS BORRRRAAAAAR
											
		}
		
	public void run(int n, OutputStream out){
		
		
		PrintStream p = new PrintStream(out);
        JSONObject s = new JSONObject ();
     
        p.println("{");
        p.println("  "+"\"states\": [");
        for(int i =0; i < n; i++) {
        	_simulador.advance();
            s=this._simulador.getState();
            p.println(s.toString()+",");

        }
        p.println("]");
        p.println("}");
		
	}

}
